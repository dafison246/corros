<?php include 'header.php'; ?>

			<section class="ds s-py-xl-160 s-py-lg-130 s-py-md-90 s-py-60 text-center comingsoon">
				<div class="container">
					<div class="row ">
						<div class="col-12">
							<h3 class="special-heading text-center">
								<span class="text-capitalize">
									Coming Soon
								</span>
							</h3>
							<div class="divider-70 hidden-below-lg"></div>
							<div class="divider-30 hidden-above-lg"></div>
							<div class="countdown_layout2" id="comingsoon-countdown2"></div>
							<div class="divider-70 hidden-below-lg"></div>
							<div class="divider-30 hidden-above-lg"></div>
							<div class="shortcode-widget-area">
								<div class="widget widget_mailchimp">
									<p>
										Subscribe to Our Newsletter:
									</p>

									<form class="signup" action="https://html.modernwebtemplates.com/">
										<label for="mailchimp_email88">
											<span class="screen-reader-text">Subscribe:</span>
										</label>
										<input id="mailchimp_email88" name="email" type="email" class="form-control mailchimp_email has-placeholder" placeholder="Email Address">
										<button type="submit" class="search-submit">
											<span class="screen-reader-text">Subscribe</span>
										</button>
										<div class="response"></div>
									</form>
								</div>
							</div>

						</div>
					</div>
				</div>
			</section>


			<section class="page_copyright ds s-py-25">
				<div class="container">
					<div class="row align-items-center">

						<div class="col-md-12 text-center">
							<p>&copy; Copyright <span class="copyright_year">2019</span> All Rights Reserved</p>
						</div>

					</div>
				</div>
			</section>
		</div><!-- eof #box_wrapper -->
	</div><!-- eof #canvas -->


	<script src="js/compressed.js"></script>
	<script src="js/main.js"></script>
	<script src="js/switcher.js"></script>

</body>


<!-- Mirrored from html.modernwebtemplates.com/nafta/comingsoon.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 18 Mar 2023 23:22:20 GMT -->
</html>